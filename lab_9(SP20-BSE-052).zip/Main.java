abstract class Student
{
    //takeXam method that prints message
    public void takeXam(){
        System.out.println("Taking Xam!");
    }
}

class PhdStudent extends Student
{
    //Overriding the takeXam method in Student class and printing appropriate message
    @Override
    public void takeXam(){
        System.out.println("Giving Final Defense Presentation!");
    }
}
//GradStudent class that is the child class of Student class
class GradStudent extends Student


{
    //Overriding the takeXam method in Student class and printing appropriate message
    @Override
    public void takeXam(){
        System.out.println("Giving Written paper!");
    }
}
//driver class
public class Main {
    public static void main(String[] args) {
        //creating Objects of PhdStudent class and GradStudent class
        PhdStudent s1=new PhdStudent();
        GradStudent s2=new GradStudent();
        //calling takeXam method from two Objects
        s1.takeXam();
        s2.takeXam();
    }
}
